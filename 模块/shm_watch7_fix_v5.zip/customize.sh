#!/system/bin/sh
# KernelSU 解包后自动执行；Magisk 也兼容
MODPATH=${MODPATH:-/data/adb/modules/shm_watch7_fix}

ui_print() { echo "$1"; }
_sp() { chown "$1:$2" "$4" 2>/dev/null; chmod "$3" "$4" 2>/dev/null; }

ui_print "- SHM Watch7 Fix v5"
ui_print "  CSC region props + powerkeeper self-heal + SAP watchdog"
[ -f "$MODPATH/module.prop" ] && _sp 0 0 0644 "$MODPATH/module.prop"
[ -f "$MODPATH/system.prop" ] && _sp 0 0 0644 "$MODPATH/system.prop"
[ -f "$MODPATH/user_configure_fixed.db" ] && _sp 0 0 0644 "$MODPATH/user_configure_fixed.db"
[ -f "$MODPATH/service.sh" ] && _sp 0 0 0755 "$MODPATH/service.sh"
[ -f "$MODPATH/customize.sh" ] && _sp 0 0 0755 "$MODPATH/customize.sh"
ui_print "- 权限已设置，重启后生效"
